/*
 * Copyright 2017 NXP
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef __ASM_ARCH_IMX8M_GPIO_H
#define __ASM_ARCH_IMX8M_GPIO_H

#include <asm/imx-common/gpio.h>

#endif /* __ASM_ARCH_MX7_GPIO_H */
