/*
 * Copyright 2017 NXP
 *
 * SPDX-License-Identifier:	GPL-2.0+
 */

#ifndef _ASM_ARCH_IMX8M_CRM_REGS_H
#define _ASM_ARCH_IMX8M_CRM_REGS_H
/* Dummy header, some imx-common code needs this file */
#endif
